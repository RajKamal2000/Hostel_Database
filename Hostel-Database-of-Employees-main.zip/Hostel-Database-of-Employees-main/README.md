# Hostel Database of Emplyees using Arrays ans Linked Lists and B-Trees.
# Various Implementations
